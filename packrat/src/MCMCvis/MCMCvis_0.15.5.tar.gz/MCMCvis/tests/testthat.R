library(testthat)
library(MCMCvis)

testthat::test_check("MCMCvis")
