context("ok: character")
test_that("ok works with character input", {
  skip_on_cran()

  expect_is(ok, "function")

  # good
  expect_true(ok(base_url))

  # bad
  expect_message(z <- ok('http://foo.bar'))
  expect_false(z)
})


context("ok: HttpClient")
test_that("ok works with HttpClient input", {
  skip_on_cran()

  # good
  z <- crul::HttpClient$new(hb("/status/200"))
  expect_true(ok(z))
  
  # bad
  z <- crul::HttpClient$new(hb("/status/404"))
  expect_false(ok(z))
})


context("ok: multiple status codes")
test_that("ok works multiple status codes", {
  skip_on_cran()

  z <- crul::HttpClient$new(hb("/status/200"))
  expect_true(ok(z, c(200L, 201L)))
  expect_error(ok(z, c(200L, 901L)))
})


context("ok: random user agent")
test_that("ok random user agents", {
  skip_on_cran()

  ua_val <- NULL
  fxn <- function(request) {
    ua <- request$options$useragent
    ua_val <<- ua
    message(paste0("User-agent: ", ua), sep = "\n")
  }
  z <- crul::HttpClient$new(hb(), hooks = list(request = fxn))
  expect_message(ok(z, ua_random = TRUE), 'User-agent:')
  # us string is one of the strings in agents
  expect_true(ua_val %in% agents)
  # agents is length 50  and character
  expect_is(agents, "character")
  expect_equal(length(agents), 50)
})


context("ok: fails well")
test_that("ok fails well", {
  skip_on_cran()

  expect_error(ok(5), "no 'ok' method for numeric")
  expect_error(ok(mtcars), "no 'ok' method for data.frame")
  expect_error(ok(list()), "no 'ok' method for list")
  expect_error(ok(), "argument \"x\" is missing")
  expect_error(ok(hb("/status/404"), status = 567L),
               "not in acceptable set")
  # ua_random must be logical
  expect_error(ok(hb("/status/404"), ua_random = "adf"))
})
