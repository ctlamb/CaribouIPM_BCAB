#' @importFrom utils globalVariables
globalVariables(c("critical.value.hall.90",
        "critical.value.hall.95",
        "critical.value.hall.99",
        "critical.value.nair.90", 
        "critical.value.nair.95",
        "critical.value.nair.99"))
