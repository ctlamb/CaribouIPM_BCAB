library(testthat)
library(bigD)

test_check("bigD")
