library(testthat)
library(overlapping)

test_check("overlapping")
