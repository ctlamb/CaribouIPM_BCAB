library("testthat")
library("tidylog")

test_check("tidylog")
