#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import rlang
#' @import utils digest
#' @importFrom fastmap fastmap faststack
#' @importFrom rlang obj_address
## usethis namespace: end
NULL
