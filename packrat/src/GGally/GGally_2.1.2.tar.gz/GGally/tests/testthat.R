
if (requireNamespace('testthat', quietly = TRUE)) {
  library(testthat)
  library(GGally)

  test_check("GGally")
}
