library(testthat)
library(slippymath)

test_check("slippymath")
