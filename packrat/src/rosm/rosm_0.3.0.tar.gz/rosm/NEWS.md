# rosm 0.3.0

* Silent deprecation the entire previous API (#20).
* Drop rgdal dependency (#21).
* Add new API based on wk and the curl package's multi
  download interface (#23).
* Update test and CI infrastructure (#27).
* Added NEWS.md to track changes in this package.

# rosm 0.2.5

* Updates to ensure compliance with CRAN policies.
